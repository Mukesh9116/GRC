import React from "react";

const UserHome = () => {
  return (
    <div className="container">

      <div className="row g-4 justify-content-center">

        {/* My Complaints */}
        <div className="col-lg-4 col-md-6">

          <div className="card dashboard-card text-center border-0">

            <div className="card-body">

              <div className="dashboard-badge">
                My Complaints
                <span>2</span>
              </div>

              <h3 className="mt-4">
                Total Complaints
              </h3>

              <div className="dashboard-icon text-danger">
                <i className="bi bi-card-list"></i>
              </div>

              <button className="btn btn-info text-dark fw-bold mt-3 px-4">
                Check
              </button>

            </div>

          </div>

        </div>

        {/* Pending */}

        <div className="col-lg-4 col-md-6">

          <div className="card dashboard-card text-center border-0">

            <div className="card-body">

              <div className="dashboard-badge">
                Pending
                <span>1</span>
              </div>

              <h3 className="mt-4">
                Pending Complaints
              </h3>

              <div className="dashboard-icon text-warning">
                <i className="bi bi-clock-history"></i>
              </div>

              <button className="btn btn-info text-dark fw-bold mt-3 px-4">
                Check
              </button>

            </div>

          </div>

        </div>

        {/* Closed */}

        <div className="col-lg-4 col-md-6">

          <div className="card dashboard-card text-center border-0">

            <div className="card-body">

              <div className="dashboard-badge">
                Closed
                <span>1</span>
              </div>

              <h3 className="mt-4">
                Closed Complaints
              </h3>

              <div className="dashboard-icon text-success">
                <i className="bi bi-check-circle-fill"></i>
              </div>

              <button className="btn btn-info text-dark fw-bold mt-3 px-4">
                Check
              </button>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
};

export default UserHome;